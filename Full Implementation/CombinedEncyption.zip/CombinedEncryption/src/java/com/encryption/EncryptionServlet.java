/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.encryption;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.security.*;
import javax.crypto.Cipher;
import java.util.Base64;

public class EncryptionServlet extends HttpServlet {

    private static String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    // Function to create a substitution table for Shift Cipher
    public static String createSubstitutionTable(int shift) {
        int length = alphabet.length();
        shift = (shift % length + length) % length; // Handle negative shifts
        return alphabet.substring(shift) + alphabet.substring(0, shift);
    }

    // Function to encrypt plaintext using Shift Cipher
    public static String shiftCipherEncrypt(String plaintext, String substitutionTable) {
        StringBuilder ciphertext = new StringBuilder();
        for (char c : plaintext.toCharArray()) {
            int index;
            if (Character.isUpperCase(c)) {
                index = alphabet.indexOf(c);
                if (index != -1) {
                    ciphertext.append(substitutionTable.charAt(index));
                } else {
                    ciphertext.append(c); // Keep characters not in alphabet as-is
                }
            } else {
                ciphertext.append(c); // Keep non-alphabet characters as-is
            }
        }
        return ciphertext.toString();
    }

    // Function to decrypt ciphertext using Shift Cipher
    public static String shiftCipherDecrypt(String ciphertext, String substitutionTable) {
        StringBuilder plaintext = new StringBuilder();
        for (char c : ciphertext.toCharArray()) {
            int index;
            if (Character.isUpperCase(c)) {
                index = substitutionTable.indexOf(c);
                if (index != -1) {
                    plaintext.append(alphabet.charAt(index));
                } else {
                    plaintext.append(c); // Keep characters not in substitution table as-is
                }
            } else {
                plaintext.append(c); // Keep non-alphabet characters as-is
            }
        }
        return plaintext.toString();
    }

    // Generate RSA key pair (public and private keys)
    public static KeyPair generateKeyPair() throws NoSuchAlgorithmException {
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(2048); // RSA key size
        return keyPairGenerator.generateKeyPair();
    }

    // Encrypt plaintext using RSA public key
    public static String rsaEncrypt(String plaintext, PublicKey publicKey) throws Exception {
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
        byte[] encryptedBytes = cipher.doFinal(plaintext.getBytes());
        return Base64.getEncoder().encodeToString(encryptedBytes); // Encode in Base64 to print as string
    }

    // Decrypt ciphertext using RSA private key
    public static String rsaDecrypt(String ciphertext, PrivateKey privateKey) throws Exception {
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        byte[] decodedBytes = Base64.getDecoder().decode(ciphertext); // Decode from Base64
        byte[] decryptedBytes = cipher.doFinal(decodedBytes);
        return new String(decryptedBytes);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String plaintext = request.getParameter("plaintext");
            int shift = Integer.parseInt(request.getParameter("shift"));

            // Step 1: Shift Cipher encryption
            String substitutionTable = createSubstitutionTable(shift);
            String shiftEncryptedText = shiftCipherEncrypt(plaintext.toUpperCase(), substitutionTable);

            // Step 2: RSA encryption
            KeyPair keyPair = generateKeyPair();
            PublicKey publicKey = keyPair.getPublic();
            PrivateKey privateKey = keyPair.getPrivate();

            // Encrypt the Shift Cipher encrypted text using RSA public key
            String rsaEncryptedText = rsaEncrypt(shiftEncryptedText, publicKey);

            // Step 3: Decrypt the message
            String rsaDecryptedText = rsaDecrypt(rsaEncryptedText, privateKey);
            String finalDecryptedText = shiftCipherDecrypt(rsaDecryptedText, substitutionTable);

            // Set the encrypted and decrypted messages as request attributes
            request.setAttribute("encryptedMessage", rsaEncryptedText);
            request.setAttribute("decryptedMessage", finalDecryptedText);

            // Forward the request to a result JSP page (or back to index.html)
            RequestDispatcher dispatcher = request.getRequestDispatcher("result.jsp");
            dispatcher.forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An error occurred during encryption/decryption.");
        }
    }
}
